﻿using EmployeeInfo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EmployeeInfo.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: Employee
        public ActionResult EmployeeMaster(string employeeType)
        {
            List<Employee> _employees = new List<Employee>();
            if (string.IsNullOrEmpty(employeeType))
            {
                _employees = DBHandler.GetEmployees();
            }
            else
            {
                if (employeeType == "All")
                {
                    _employees = DBHandler.GetEmployees();
                }
                else
                {
                    EmployeeType myStatus;
                    Enum.TryParse(employeeType, out myStatus);
                    _employees = DBHandler.GetEmployees().Where(x => x.eEmployeeType == myStatus).ToList();
                }
               
            }
            return View(_employees);
        }
    }
}
