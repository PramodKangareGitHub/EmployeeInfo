﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace EmployeeInfo.Models
{
    public class Employee
    {
        [DisplayName("Employee Id")]
        public int iEmployeeId { get; set; }
        [DisplayName("First Name")]
        public string sFirstName { get; set; }
        [DisplayName("Last Name")]
        public string sLastName { get; set; }
        [DisplayName("Gender")]
        public Gender eGender { get; set; }
        [DisplayName("Employee Type")]
        public EmployeeType eEmployeeType { get; set; }
        public string Department { get; set; }
    }
}