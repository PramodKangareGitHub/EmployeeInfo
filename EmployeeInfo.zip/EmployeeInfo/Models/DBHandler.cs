﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmployeeInfo.Models
{
    public static class DBHandler
    {
        public static List<Employee> GetEmployees()
        {
            List<Employee> _employees = new List<Employee>();
            try
            {
                _employees = new List<Employee>()
                {
                    new Employee() { iEmployeeId = 1,sFirstName="Sachin",sLastName="More",eGender=Gender.Male,eEmployeeType=EmployeeType.FullTime,Department="Software"},
                    new Employee() { iEmployeeId = 2,sFirstName="Pankaj",sLastName="Tripathi",eGender=Gender.Male,eEmployeeType=EmployeeType.Contractor,Department="Software"},
                    new Employee() { iEmployeeId = 3,sFirstName="Anil",sLastName="Jadhav",eGender=Gender.Male,eEmployeeType=EmployeeType.FullTime,Department="Software"},
                    new Employee() { iEmployeeId = 4,sFirstName="Shivaji",sLastName="Jadhav",eGender=Gender.Male,eEmployeeType=EmployeeType.FullTime,Department="Account"},
                    new Employee() { iEmployeeId = 5,sFirstName="Kiran",sLastName="Yadav",eGender=Gender.Male,eEmployeeType=EmployeeType.FullTime,Department="Account"},
                    new Employee() { iEmployeeId = 6,sFirstName="Amruta",sLastName="Desai",eGender=Gender.Female,eEmployeeType=EmployeeType.Contractor,Department="Hardware"},
                    new Employee() { iEmployeeId = 7,sFirstName="Deepali",sLastName="Joshi",eGender=Gender.Female,eEmployeeType=EmployeeType.FullTime,Department="Account"},
                    new Employee() { iEmployeeId = 8,sFirstName="Rupali",sLastName="Raut",eGender=Gender.Female,eEmployeeType=EmployeeType.FullTime,Department="Software"},
                    new Employee() { iEmployeeId = 9,sFirstName="Pooja",sLastName="Kale",eGender=Gender.Female,eEmployeeType=EmployeeType.Contractor,Department="Hardware"},
                    new Employee() { iEmployeeId = 10,sFirstName="Ganesh",sLastName="Badak",eGender=Gender.Male,eEmployeeType=EmployeeType.FullTime,Department="HR"},
                    new Employee() { iEmployeeId = 11,sFirstName="Sachin",sLastName="Vishwakarma",eGender=Gender.Male,eEmployeeType=EmployeeType.Contractor,Department="Hardware"},
                    new Employee() { iEmployeeId = 12,sFirstName="Rahul",sLastName="Tripathi",eGender=Gender.Male,eEmployeeType=EmployeeType.FullTime,Department="Software"},
                    new Employee() { iEmployeeId = 13,sFirstName="Chetan",sLastName="Borate",eGender=Gender.Male,eEmployeeType=EmployeeType.FullTime,Department="Hardware"},
                    new Employee() { iEmployeeId = 14,sFirstName="Ketki",sLastName="Nivangune",eGender=Gender.Female,eEmployeeType=EmployeeType.Contractor,Department="Account"},
                    new Employee() { iEmployeeId = 15,sFirstName="Vishesh",sLastName="Bhagat",eGender=Gender.Male,eEmployeeType=EmployeeType.FullTime,Department="Hardware"},
                    new Employee() { iEmployeeId = 16,sFirstName="Kapil",sLastName="Karandikar",eGender=Gender.Male,eEmployeeType=EmployeeType.Contractor,Department="Account"},
                    new Employee() { iEmployeeId = 17,sFirstName="Anil",sLastName="Joshi",eGender=Gender.Male,eEmployeeType=EmployeeType.FullTime,Department="Hardware"},
                    new Employee() { iEmployeeId = 18,sFirstName="Omkar",sLastName="Jadhav",eGender=Gender.Male,eEmployeeType=EmployeeType.FullTime,Department="Software"},
                    new Employee() { iEmployeeId = 19,sFirstName="Maqsud",sLastName="Momin",eGender=Gender.Male,eEmployeeType=EmployeeType.FullTime,Department="Software"},
                    new Employee() { iEmployeeId = 20,sFirstName="Ishwar",sLastName="Jadhav",eGender=Gender.Male,eEmployeeType=EmployeeType.Contractor,Department="Administrator"},
                    new Employee() { iEmployeeId = 21,sFirstName="Santsoh",sLastName="Deshmane",eGender=Gender.Male,eEmployeeType=EmployeeType.FullTime,Department="Administrator"},
                    new Employee() { iEmployeeId = 22,sFirstName="Somanetra",sLastName="Bose",eGender=Gender.Female,eEmployeeType=EmployeeType.FullTime,Department="Administrator"},
                    new Employee() { iEmployeeId = 23,sFirstName="Pooja",sLastName="Raste",eGender=Gender.Female,eEmployeeType=EmployeeType.Contractor,Department="Software"},
                    new Employee() { iEmployeeId = 24,sFirstName="Ganesh",sLastName="Badak",eGender=Gender.Male,eEmployeeType=EmployeeType.FullTime,Department="Software"},
                    new Employee() { iEmployeeId = 25,sFirstName="Aarti",sLastName="Kumar",eGender=Gender.Female,eEmployeeType=EmployeeType.Contractor,Department="Software"},
                    new Employee() { iEmployeeId = 26,sFirstName="Neha",sLastName="Tripathi",eGender=Gender.Female,eEmployeeType=EmployeeType.FullTime,Department="Software"},
                    new Employee() { iEmployeeId = 27,sFirstName="Pramod",sLastName="Kangare",eGender=Gender.Male,eEmployeeType=EmployeeType.FullTime,Department="Software"},
                    new Employee() { iEmployeeId = 28,sFirstName="Ketki",sLastName="Desai",eGender=Gender.Female,eEmployeeType=EmployeeType.Contractor,Department="Software"},
                };
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return _employees;
        }
    }
}