﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmployeeInfo.Models
{
    public enum Gender
    {
        Male=0,
        Female=0
    }
    public enum EmployeeType
    {
        FullTime=0,
        Contractor=1
    }
}